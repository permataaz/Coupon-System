<?php
  $dbuser= "root";
  $dbpass = "";
  $dbhost = "localhost";
  $dbname = "its332new2020";

  $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
 ?>
