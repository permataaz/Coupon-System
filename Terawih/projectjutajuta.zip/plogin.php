<?php
//save this file as plogin.php
include("connection.php");

$studno = mysqli_real_escape_string($conn, $_POST['studno']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$sql = "SELECT * FROM dem WHERE demID = '".$studno."' AND passwordD = '".$password."'";
$qry = mysqli_query($conn, $sql);
$row = mysqli_num_rows($qry);

if ( $row > 0)
{
  $r = mysqli_fetch_assoc($qry);
  session_start();
  $_SESSION['userlogged'] = 1;
  $_SESSION['studentno'] = $studno;
  $_SESSION['studentname'] = $r['studentname'];
  $_SESSION['userlevelid'] = $r['userlevelid'];
  $_SESSION['userlevelname'] = $r['userlevelname'];

  header("Location: dashboard.php");
}
else
{
  echo "<script language ='javascript'> alert('User does not exist.');window.location='demlogin.php';</script>";
}
 ?>
